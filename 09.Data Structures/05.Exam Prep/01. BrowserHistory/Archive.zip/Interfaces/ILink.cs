﻿namespace _01._BrowserHistory.Interfaces
{
    public interface ILink
    {
        string Url { get; set; }

        int LoadingTime { get; set; }
    }
}
