﻿namespace Chushka.Models
{
    public enum ProductType
    {
        Food,
        Domestic,
        Health,
        Cosmetic,
        Other
    }
}