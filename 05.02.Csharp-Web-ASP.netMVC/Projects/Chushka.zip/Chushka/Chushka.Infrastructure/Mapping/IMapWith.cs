﻿namespace Chushka.Infrastructure.Mapping
{
    public interface IMapWith<TModel>
    {
    }
}
