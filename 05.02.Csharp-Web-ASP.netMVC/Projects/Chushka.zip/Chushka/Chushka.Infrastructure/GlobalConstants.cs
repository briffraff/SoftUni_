namespace Chushka.Infrastructure
{
    public static class GlobalConstants
    {
        public const string AdminRoleName = "Admin";
    }
}