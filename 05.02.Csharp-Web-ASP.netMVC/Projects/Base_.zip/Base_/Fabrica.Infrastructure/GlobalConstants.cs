﻿namespace Fabrica.Infrastructure
{
    using System;

    public class GlobalConstants
    {

    }
}
