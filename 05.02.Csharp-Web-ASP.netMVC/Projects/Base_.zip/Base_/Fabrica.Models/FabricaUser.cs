﻿namespace Fabrica.Models
{
    using System;
    using Microsoft.AspNetCore.Identity;

    public class FabricaUser : IdentityUser
    {

    }
}
