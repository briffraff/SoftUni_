﻿namespace Eventures.Infrastructure.Mapping
{
    public interface IMapWith<TModel>
    {
    }
}
