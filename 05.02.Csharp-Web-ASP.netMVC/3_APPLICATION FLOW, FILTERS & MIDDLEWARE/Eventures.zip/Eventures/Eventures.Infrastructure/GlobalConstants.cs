namespace Eventures.Infrastructure
{
    public static class GlobalConstants
    {
        public const string AdminRoleName = "Administrator";
    }
}