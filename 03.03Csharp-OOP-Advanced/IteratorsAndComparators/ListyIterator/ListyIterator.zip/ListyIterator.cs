﻿using System;
using System.Collections.Generic;
using System.Text;
using ListyIterator.Interfaces;

namespace ListyIterator
{
    public class ListyIterator<T> : IListyIteratorable
    {
        //fields
        private T[] elements;
        private int index;

        //ctor
        public ListyIterator(T[] elements)
        {
            this.elements = elements;
            this.index = 0;
        }

        //props
        public T[] Elements
        {
            get { return elements; }
            set { elements = value; }
        }

        public int Index
        {
            get { return index; }
            set { index = value; }
        }


        //Meths
        public bool Move()
        {
            if (this.index < this.Elements.Length - 1)
            {
                this.index++;
                return true;
            }

            return false;
        }

        public bool HasNext()
        {
            if (this.index < this.Elements.Length - 1)
            {
                return true;
            }

            return false;
        }

        public void Print()
        {
            string currentElement = this.Elements[this.Index].ToString();
            Console.WriteLine(currentElement);
        }
    }
}
