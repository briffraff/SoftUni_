using HAD.Entities.Items;
using HAD.Entities.Miscellaneous;
using NUnit.Framework;

namespace HAD.Tests
{
    public class HeroInventoryTests
    {
        [SetUp]
        public void Setup()
        {
        }
    }
}