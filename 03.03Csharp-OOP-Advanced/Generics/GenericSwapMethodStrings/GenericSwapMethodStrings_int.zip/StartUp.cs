﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericSwapMethodStrings
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            
            List<int> messages = new List<int>();

            for (int i = 0; i < n; i++)
            {
                int message = int.Parse(Console.ReadLine());
                messages.Add(message);
            }

            int[] indexes = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(x => int.Parse(x))
                .ToArray();

            TheList<int> list = new TheList<int>(messages);
            list.Swap(indexes[0],indexes[1]);
            Console.WriteLine(list);


        }
    }
}
