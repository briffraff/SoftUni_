﻿namespace WildFarm.Animals.Birds.Interfaces
{
    public interface IBird
    {
        double WingSize { get; }
    }
}
