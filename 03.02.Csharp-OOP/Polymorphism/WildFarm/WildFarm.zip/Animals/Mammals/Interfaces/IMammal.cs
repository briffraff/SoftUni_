﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Animals.Mammals.Interfaces
{
    public interface IMammal
    {
        string LivingRegion { get; }
    }
}
