﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Animals.Mammals.Feline.Interfaces
{
    public interface IFeline
    {
        string Breed { get; }
    }
}
