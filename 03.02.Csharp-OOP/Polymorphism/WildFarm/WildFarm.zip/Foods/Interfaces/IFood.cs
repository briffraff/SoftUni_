﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Foods.Interfaces
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
