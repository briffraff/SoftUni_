﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalFarm
{
    class Frog : Animal
    {
        public Frog(string name, int age, string gender) : base(name, age, gender)
        {
        }
    }
}
