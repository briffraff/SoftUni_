﻿using System;
using Ferrari.Core;

namespace Ferrari
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
