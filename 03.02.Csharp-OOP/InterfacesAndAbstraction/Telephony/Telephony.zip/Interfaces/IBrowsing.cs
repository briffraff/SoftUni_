﻿namespace Telephony.Interfaces
{
    public interface IBrowsing
    {
        void Browse(string webpage);
    }
}
