﻿namespace Telephony.Interfaces
{
    public interface ICalling
    {
        void Call(string number);
    }
}
