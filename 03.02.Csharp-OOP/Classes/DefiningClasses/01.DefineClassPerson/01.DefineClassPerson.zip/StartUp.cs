﻿using System;
using System.Reflection;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main()
        {
            Person person = new Person("Pesho",20);
 
        }
    }
}

