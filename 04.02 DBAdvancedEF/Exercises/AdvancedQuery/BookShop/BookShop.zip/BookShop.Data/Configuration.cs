﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=RR-PC\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
