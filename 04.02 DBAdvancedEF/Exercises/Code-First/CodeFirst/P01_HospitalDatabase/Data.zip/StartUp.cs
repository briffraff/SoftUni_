﻿
namespace P01_HospitalDatabase
{
    using System;

    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
