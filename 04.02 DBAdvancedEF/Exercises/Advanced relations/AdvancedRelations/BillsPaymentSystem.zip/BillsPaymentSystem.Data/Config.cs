﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BillsPaymentSystem.Data
{
    public class Config
    {
        public const string ConnectionString = "Server=RR-PC\\SQLEXPRESS;Database=billsPaymentDatabase;Integrated Security=True;";
    }
}
