﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BillsPaymentSystem.Data.EntityConfiguration
{
   public  class PaymentMethodConfig
    {
    }
}
