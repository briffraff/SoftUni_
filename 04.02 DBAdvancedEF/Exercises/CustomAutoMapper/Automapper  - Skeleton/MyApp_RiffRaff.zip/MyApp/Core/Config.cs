﻿using System;
using System.Collections.Generic;
using System.Net.Security;
using System.Runtime.CompilerServices;
using System.Text;
using MyApp.Core.Contracts;

namespace MyApp.Core
{
    public class Config
    {
        public const string ConnectionString = "Server = RR-PC\\SQLEXPRESS; Database = MyAppDB; Integrated Security = True;";
 
    }


}
