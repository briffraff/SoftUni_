﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyApp.Core.ViewModels
{
    public class EmployeePersonalInfoDto
    {
        public DateTime? Birthday { get; set; }
        public string Address { get; set; }
    }
}
